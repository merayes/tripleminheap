package Odev;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		System.out.print("sayilari giriniz : ");
		String girdi = input.nextLine();

		String[] dizi = girdi.split(",", 30);

		int[] AnaDizi = new int[dizi.length];

		for (int counter = 0; counter < dizi.length; counter++) {

			AnaDizi[counter] = Integer.parseInt(dizi[counter]);
		}

		TripleMinHeap heap = new TripleMinHeap();
		heap.dizi = AnaDizi;
		heap.buildMinHeap();

	}

}
